/* 영업관리 메뉴 데이터 흐름 시뮬레이션 (jsdom + 인메모리 MESDB 모의) */
const fs=require('fs'),path=require('path');
const {JSDOM}=require('jsdom');
const P='/mnt/project';
const LOG=[];const ok=(t,c,d)=>{LOG.push({t,c:!!c,d});console.log((c?'  ✅ ':'  ❌ ')+t+(d?'  → '+d:''))};
const info=t=>console.log('  · '+t);

/* ───────── 인메모리 DB ───────── */
const IDENT={sale_order_status_rows:'row_no',sales_plans:'row_no',sales_plan_status_rows:'row_no',
 set_order_lines:'line_id',expenses:'expense_id',set_order_registrations:'row_no',sale_orders:'row_no'};
const PK={jobs:'job_no',sale_orders:'job_no',sale_order_status_rows:'row_no',sales_plans:'row_no',
 sales_plan_status_rows:'row_no',set_order_lines:'line_id',expenses:'expense_id',expense_reasons:'expense_reason_code',
 set_order_partners:'row_no',vendors:'vendor_name',notices:'row_no',set_order_registrations:'row_no'};
const FK={sale_orders:['job_no','jobs'],sales_plans:null,set_order_lines:['job_no','jobs'],expenses:['job_no','jobs']};
const UNIQ={set_order_lines:['job_no','partner_vendor_name','set_seq','process_name']};
const T={order_lines:[],jobs:[],sale_orders:[],sale_order_status_rows:[],sales_plans:[],sales_plan_status_rows:[],
 set_order_lines:[],expenses:[],set_order_registrations:[],
 expense_reasons:[{expense_reason_code:'E01',expense_reason_name:'출장비'},{expense_reason_code:'E02',expense_reason_name:'접대비'}],
 set_order_partners:[{row_no:1,partner_vendor_name:'삼호텍'},{row_no:2,partner_vendor_name:'금도금속'}],
 vendors:[{vendor_name:'삼호텍'},{vendor_name:'금도금속'},{vendor_name:'서성정기'}],
 notices:[],quality_kpi_summary_view:[]};
const seq={};const nextId=(t)=>{seq[t]=(seq[t]||Math.max(0,...T[t].map(r=>Number(r[IDENT[t]])||0)))+1;return seq[t]};
const SQL=[];   /* 호출 기록 */
function views(name){
 const so=j=>T.sale_orders.find(x=>x.job_no===j)||{};
 const sr=j=>T.sale_order_status_rows.find(x=>x.job_no===j)||{};
 if(name==='set_order_job_pool')return T.jobs.filter(j=>so(j.job_no).order_status!=='취소'&&so(j.job_no).job_no)
   .map((j,i)=>({row_no:i+1,job_no:j.job_no,item_name:so(j.job_no).item_name,completion_planned_date:so(j.job_no).completion_date,
     s1_date:so(j.job_no).s1_planned_date,customer_request_date:so(j.job_no).delivery_planned_date,customer_name:so(j.job_no).customer_name,
     order_type:so(j.job_no).order_type,order_status:so(j.job_no).order_status,order_price:so(j.job_no).order_price,plant_name:'1공장'}));
 if(name==='set_order_job_list'){const jobs=[...new Set(T.set_order_lines.map(l=>l.job_no))];
   return jobs.map((j,i)=>{const ls=T.set_order_lines.filter(l=>l.job_no===j);const open=ls.filter(l=>l.status==='발주').length;
     return {row_no:i+1,job_no:j,item_name:so(j).item_name,completion_planned_date:so(j).completion_date,s1_date:so(j).s1_planned_date,
       customer_request_date:so(j).delivery_planned_date,line_cnt:ls.length,open_cnt:open,done_cnt:ls.length-open,receipt_status:open?'미완료':'완료'}})}
 if(name==='set_order_status_view')return T.set_order_lines.map((l,i)=>{const s=so(l.job_no);const op=Number(s.order_price)||0;
   return {row_no:i+1,line_id:l.line_id,job_no:l.job_no,status:l.status,item_name:s.item_name,model:s.model,domestic_overseas:s.domestic_overseas,
     customer_name:s.customer_name,order_price:s.order_price,set_seq:l.set_seq,process_name:l.process_name,partner_vendor_name:l.partner_vendor_name,
     paid_supply:s.order_type==='유상사급'?'유상':null,quotation_price:l.quote_price,negotiated_price:l.nego_price,
     difference:Number(l.quote_price||0)-Number(l.nego_price||0),execution_rate_pct:op?+(Number(l.nego_price||0)/op*100).toFixed(2):null,
     receipt_date:l.receipt_date,order_date:l.order_date,receipt_planned_date:l.receipt_planned_date,unit_price:l.unit_price,writer:l.writer,confirmed_by:l.confirmed_by,plant_name:'1공장'}});
 if(name==='expense_status_view')return T.expenses.map(e=>({...e,item_name:so(e.job_no).item_name,customer_name:e.customer_name||so(e.job_no).customer_name}));
 if(name==='status_board_pool')return T.jobs.filter(j=>!['취소','완료'].includes(so(j.job_no).order_status)).map((j,i)=>{const s=so(j.job_no);
   const pl=T.sales_plans.find(p=>p.job_no===j.job_no)||{};const today=new Date().toISOString().slice(0,10);
   return {row_no:i+1,job_no:j.job_no,item_name:s.item_name,order_date:s.order_date,s1_due_date:s.s1_planned_date,completion_due_date:s.delivery_planned_date,
     sales_manager:s.manager_name,assembly_manager:pl.assembly_manager,s1_overdue:!!(s.s1_planned_date&&s.s1_planned_date<today),
     completion_overdue:!!(s.delivery_planned_date&&s.delivery_planned_date<today),page:Math.floor(i/15)+1}});
 return null;
}
function parseQ(q){const o={select:'*',filters:[],order:null,limit:null};
 for(const kv of String(q).split('&')){const i=kv.indexOf('=');const k=kv.slice(0,i),v=decodeURIComponent(kv.slice(i+1));
  if(k==='select')o.select=v;else if(k==='order'){const [c,d]=v.split('.');o.order={c,d:d||'asc'}}else if(k==='limit')o.limit=+v;
  else if(k==='on_conflict')o.on_conflict=v;else{const m=v.match(/^(eq|gte|lte)\.(.*)$/);if(m)o.filters.push({k,op:m[1],v:m[2]})}}
 return o}
function mkDB(){
 const bus=DBBUS;
 const table=name=>({
  select:async(q='select=*')=>{SQL.push(['SELECT',name,q]);const p=parseQ(q);let rows=views(name)||T[name];if(!rows)throw new Error('404 relation '+name);
   rows=rows.filter(r=>p.filters.every(f=>{const a=r[f.k];return f.op==='eq'?String(a)===f.v:f.op==='gte'?String(a)>=f.v:String(a)<=f.v}));
   if(p.order)rows=[...rows].sort((a,b)=>(a[p.order.c]>b[p.order.c]?1:-1)*(p.order.d==='desc'?-1:1));
   if(p.limit)rows=rows.slice(0,p.limit);
   const cols=p.select==='*'?null:p.select.split(',');
   return rows.map(r=>{const o={};for(const k of (cols||Object.keys(r)))o[k]=r[k]===undefined?null:r[k];return JSON.parse(JSON.stringify(o))})},
  upsert:async(rows,onConflict)=>{SQL.push(['UPSERT',name,onConflict,JSON.stringify(rows).slice(0,200)]);const a=Array.isArray(rows)?rows:[rows];
   const keys=[];for(const r of a)for(const k in r)if(!keys.includes(k))keys.push(k);
   if(!T[name])throw new Error('404 relation '+name);
   for(const r0 of a){const r={};for(const k of keys)r[k]=r0[k]===undefined?null:r0[k];
    if(FK[name]){const [c,pt]=FK[name];if(r[c]!=null&&!T[pt].some(x=>x[PK[pt]]===r[c]))throw new Error('참조 무결성 위반: 마스터에 없는 코드입니다. 기준정보에 먼저 등록하세요.')}
    if(name==='set_order_lines'&&r.partner_vendor_name&&!T.vendors.some(v=>v.vendor_name===r.partner_vendor_name))throw new Error('참조 무결성 위반: 마스터에 없는 코드입니다. 기준정보에 먼저 등록하세요.');
    const key=onConflict||PK[name];
    let ex=key&&r[key]!=null?T[name].find(x=>String(x[key])===String(r[key])):null;
    if(!ex&&UNIQ[name]){const u=T[name].find(x=>UNIQ[name].every(k=>x[k]===r[k]));if(u){if(onConflict)ex=null;else throw new Error('409 duplicate key value violates unique constraint')}}
    if(ex){Object.assign(ex,r)}else{
     if(IDENT[name]&&r[IDENT[name]]==null)r[IDENT[name]]=nextId(name);
     if(PK[name]&&r[PK[name]]==null)throw new Error('null value in column "'+PK[name]+'" violates not-null constraint');
     if(T[name].some(x=>String(x[PK[name]])===String(r[PK[name]])))throw new Error('409 duplicate key value violates unique constraint "'+name+'_pkey"');
     T[name].push(r)}}
   return null},
  delete:async(match)=>{SQL.push(['DELETE',name,JSON.stringify(match)]);
   if(name==='set_order_lines'){const tg=T[name].filter(r=>Object.entries(match).every(([k,v])=>String(r[k])===String(v)));
    if(tg.some(r=>r.status!=='발주'))throw new Error('입고된 라인은 삭제할 수 없습니다 (set_order_lines_no_del_trg)')}
   T[name]=T[name].filter(r=>!Object.entries(match).every(([k,v])=>String(r[k])===String(v)));return null},
  insertOne:async(row)=>{SQL.push(['INSERT',name,JSON.stringify(row).slice(0,200)]);const r={...row};
   if(FK[name]){const [c,pt]=FK[name];if(r[c]!=null&&!T[pt].some(x=>x[PK[pt]]===r[c]))throw new Error('참조 무결성 위반')}
   if(IDENT[name]&&r[IDENT[name]]==null)r[IDENT[name]]=nextId(name);T[name].push(r);return JSON.parse(JSON.stringify(r))}
 });
 const DB={online:true,ready:Promise.resolve(),table,notify:tables=>bus.emit(tables),onChange:(tables,fn)=>bus.on(tables,fn)};
 DB.master=async function(opt){const map={};for(const k in opt.map){const v=opt.map[k];map[k]=typeof v==='string'?{col:v,type:'text'}:{type:'text',...v}}
  const rows=await table(opt.table).select('select=*');const a=opt.get();a.length=0;
  a.push(...rows.map(r=>{const o={};for(const k in map){let v=r[map[k].col];if(map[k].type==='num')v=(v==null?'':v);else if(map[k].type==='bool')v=!!v;else v=(v==null?'':String(v));o[k]=v}return o}));
  let snap=new Map(a.map(r=>[String(r[opt.pk]),JSON.stringify(r)]));
  try{(opt.render||(()=>{}))()}catch(e){console.log('render err',e.message)}
  let selfAt=0;
  DB.onChange([opt.table],()=>{if(Date.now()-selfAt<1500)return;setTimeout(async()=>{const rows=await table(opt.table).select('select=*');const a=opt.get();a.length=0;
    a.push(...rows.map(r=>{const o={};for(const k in map){let v=r[map[k].col];if(map[k].type==='num')v=(v==null?'':v);else if(map[k].type==='bool')v=!!v;else v=(v==null?'':String(v));o[k]=v}return o}));
    try{(opt.render||(()=>{}))()}catch(e){};snap=new Map(a.map(r=>[String(r[opt.pk]),JSON.stringify(r)]))},20)});
  DB.syncMaster=async()=>{const cur=opt.get();const up=[],del=[];const ks=new Set(cur.map(r=>String(r[opt.pk])));
   for(const r of cur)if(snap.get(String(r[opt.pk]))!==JSON.stringify(r)){const o={};for(const k in map){let v=r[k];if(map[k].type==='num')v=(v===''||v==null)?null:Number(v);else v=(v===''||v==null)?null:v;o[map[k].col]=v}up.push(o)}
   for(const k of snap.keys())if(!ks.has(k))del.push(k);
   if(up.length)await table(opt.table).upsert(up,map[opt.pk].col);for(const k of del)await table(opt.table).delete({[map[opt.pk].col]:k});
   snap=new Map(cur.map(r=>[String(r[opt.pk]),JSON.stringify(r)]));if(up.length||del.length){selfAt=Date.now();DB.notify([opt.table])}};
 };
 return DB;
}
const DBBUS={subs:[],on(t,fn){this.subs.push({t:new Set(Array.isArray(t)?t:[t]),fn})},emit(t){const l=Array.isArray(t)?t:[t];for(const s of this.subs)if(l.some(x=>s.t.has(x))){try{s.fn({tables:l})}catch(e){}}}};

/* ───────── 화면 로더 ───────── */
function load(file,extra){
 let html=fs.readFileSync(path.join(P,file),'utf8').replace(/<script[^>]*src=[^>]*><\/script>/g,'')
   .replace(/<script[^>]*src=[^>]*>[\s\S]*?<\/script>/g,'');
 const dom=new JSDOM(html,{runScripts:'dangerously',pretendToBeVisual:true,
  beforeParse(w){w.MESDB=mkDB();w.MESLOOK={bindPair(){}};w.MESJOB={attach(){}};w.MESSAMPLE=null;w.MESDEMO=null;
   w.confirm=()=>true;w.alert=()=>{};w.MES_AUTH={name:'테스터',token:'t'};w.URL.createObjectURL=()=>'';
   w.HTMLAnchorElement.prototype.click=function(){};w.console.warn=()=>{};if(extra)extra(w)}});
 return dom.window;
}
const tick=(ms=30)=>new Promise(r=>setTimeout(r,ms));
const setv=(w,id,v)=>{const n=w.document.getElementById(id);if(!n)throw new Error('no element #'+id);n.value=v;n.dispatchEvent(new w.Event('input'))};

(async()=>{
 console.log('\n━━━ 1. 수주등록 (sale_order_input) ━━━');
 let w=load('sale_order_input.html');await tick();
 const F={job_no:'J26201',order_date:'2026-09-01',s1p:'2026-10-05',dlvp:'2026-11-20',status:'진행',otype:'신작',
  item_code:'J',item_name:'BRACKET,HEATER',drawing_no:'MAZ63491310',dom:'국내',mgr_code:'user01',mgr_name:'권태윤',
  cust_code:'V030',cust_name:'서성정기',mold_code:'M01',mold_name:'PROGRESSIVE',devtype:'사내',mp_code:'V028',mp_name:'서한산업',
  product_name:'히터브라켓',model:'LUPIN3',proc_cnt:'1/1',quo_price:'52000000',ms_code:'S03',ms_name:'250 TON',
  order_price:'50000000',sales_price:'51000000',remark:'시뮬'};
 for(const [k,v] of Object.entries(F))setv(w,k,v);
 let r=await w.MES.save('등록');
 ok('save() 반환 true',r,w.document.getElementById('message').textContent);
 ok('jobs 생성',T.jobs.length===1&&T.jobs[0].job_no==='J26201');
 ok('sale_orders 생성',T.sale_orders.length===1);
 ok('sale_order_status_rows 생성',T.sale_order_status_rows.length===1,'row_no='+T.sale_order_status_rows[0]?.row_no);
 const so=T.sale_orders[0];
 ok('금액 숫자 저장 (order_price 50,000,000)',so.order_price===50000000,String(so.order_price));
 ok('공정 "1/1" 입력이 보존되는가',so.process_set_qty==='1/1','process_set_qty='+JSON.stringify(so.process_set_qty)+' / status.set_qty='+JSON.stringify(T.sale_order_status_rows[0].set_qty));
 ok('jobs.item_name/customer_name 동기화',T.jobs[0].item_name==='BRACKET,HEATER'&&T.jobs[0].customer_name==='서성정기');
 /* 수정 저장 */
 setv(w,'order_price','48000000');setv(w,'item_name','BRACKET,HEATER-R');
 r=await w.MES.save('수정');
 ok('수정 저장 후 수주현황 중복행 없음',T.sale_order_status_rows.length===1,'rows='+T.sale_order_status_rows.length);
 ok('수정값 sale_orders 반영',T.sale_orders[0].order_price===48000000&&T.sale_orders[0].item_name==='BRACKET,HEATER-R');
 ok('수정값 수주현황행 반영',T.sale_order_status_rows[0].item_name==='BRACKET,HEATER-R');
 ok('수정값 jobs 반영',T.jobs[0].item_name==='BRACKET,HEATER-R');
 /* 빈 화면에서 제번 입력 → 자동 로드 */
 w.MES.clearForm();setv(w,'job_no','J26201');w.document.getElementById('job_no').dispatchEvent(new w.Event('change'));await tick(50);
 ok('제번 change → 기존 수주 자동 로드',w.document.getElementById('cust_name').value==='서성정기'&&w.document.getElementById('order_price').value==='48000000',w.document.getElementById('message').textContent);
 ok('필수 검증: 제번 없으면 저장 거부',await (async()=>{w.MES.clearForm();return (await w.MES.save('등록'))===false})());
 /* 두 번째 수주 (경비/현황판 비교용) */
 w.MES.clearForm();for(const [k,v] of Object.entries({...F,job_no:'J26202',item_name:'COVER,REAR',order_price:'30000000',quo_price:'',s1p:'2026-08-20',dlvp:'2026-08-30'}))setv(w,k,v);
 await w.MES.save('등록');ok('2건째 수주 등록',T.sale_orders.length===2&&T.sale_order_status_rows.length===2);
 const soWin=w;

 console.log('\n━━━ 2. 수주현황 (sale_order_status) ━━━');
 w=load('sale_order_status.html');await tick(50);
 let vis=[...w.document.querySelectorAll('#body tr')].map(tr=>tr.cells[1]?.textContent);
 ok('DB 행이 화면에 표시(사진 판독 시드 대체)',vis.includes('J26201')&&vis.includes('J26202')&&vis.length===2,'rows='+vis.length);
 await tick(30);
 ok('합계줄에 수주가 합산(sale_orders 조인)',/수주가 78,000,000/.test(w.document.getElementById('totline').textContent),w.document.getElementById('totline').textContent);
 ok('견적가 미등록건 제외 표기',/금액 미등록/.test(w.document.getElementById('totline').textContent)===false,'(두 건 모두 sale_orders 존재 → 제외문구 없음이 정상)');
 /* 상세 팝업 */
 w.document.querySelectorAll('#body tr')[0].click();await tick(30);
 ok('행 클릭 → 상세팝업에 sale_orders 값 병합',/48,000,000/.test(w.document.getElementById('dQBody').textContent)&&/권태윤/.test(w.document.getElementById('dQBody').textContent));
 /* 수정 버튼: iframe 부모 없음 */
 w.MES.editOrder();
 ok('[수정] 단독 실행 시 안내 메시지 (index 안에서만 이동)',/열 수 없습니다/.test(w.document.getElementById('message').textContent),w.document.getElementById('message').textContent);
 /* 수주등록 저장 → 수주현황 자동 갱신 (notify) */
 setv(soWin,'job_no','J26201');soWin.document.getElementById('job_no').dispatchEvent(new soWin.Event('change'));await tick(40);
 setv(soWin,'model','LUPIN3-B');await soWin.MES.save('수정');await tick(60);
 const cellModel=[...w.document.querySelectorAll('#body tr')].find(tr=>tr.cells[1].textContent==='J26201')?.cells[2].textContent;
 ok('수주등록 저장 후 수주현황 자동갱신(notify→onChange)',cellModel==='LUPIN3-B','화면 model='+cellModel);
 const sosWin=w;

 console.log('\n━━━ 3. 제작계획등록 (sales_plan_input) ━━━');
 w=load('sales_plan_input.html');await tick();
 setv(w,'job_no','J26201');await w.loadJob();
 ok('제번 입력 → 수주정보 헤더 자동채움',w.document.getElementById('customer_name').value==='서성정기'&&w.document.getElementById('order_price').value==='48000000'&&w.document.getElementById('item_name').value==='BRACKET,HEATER-R',w.document.getElementById('message').textContent);
 ok('수주가→제작계획 order_price 상속',w.document.getElementById('order_price').value==='48000000');
 setv(w,'target_price','40000000');
 const amt={a1:3000000,a2:0,a3:5000000,a4:2000000,a5:20000000,a6:4000000,a7:5000000,a8:1000000};
 for(const [k,v] of Object.entries(amt))setv(w,k,v);
 setv(w,'design_start_date','2026-09-03');setv(w,'design_end_date','2026-09-10');setv(w,'design_days','6');setv(w,'design_manager','김설계');
 setv(w,'assembly_manager','박조립');w.recalc();
 ok('이익률 자동계산 (48M-40M)/48M=16.7%',w.document.getElementById('profit_rate_pct').value==='16.7',w.document.getElementById('profit_rate_pct').value);
 ok('비율 = 금액/목표가 (가공사내 20M/40M=50%)',w.document.getElementById('p5').textContent==='50%');
 await w.save();
 ok('sales_plans 저장',T.sales_plans.length===1,w.document.getElementById('message').textContent);
 ok('sales_plan_status_rows 저장',T.sales_plan_status_rows.length===1,'row_no='+JSON.stringify(T.sales_plan_status_rows[0]?.row_no));
 const spr=T.sales_plan_status_rows[0]||{};
 ok('현황행 가공=사내+사외 24,000,000',spr.machining_amount===24000000,String(spr.machining_amount));
 ok('현황행 기타=설계+원재료+구매 10,000,000',spr.etc_amount===10000000,String(spr.etc_amount));
 ok('현황행 row_no 가 sales_plans.row_no 와 동일',spr.row_no===T.sales_plans[0].row_no,`plan=${T.sales_plans[0].row_no} status=${spr.row_no}`);
 /* 수정 저장 → 중복 검사 */
 setv(w,'target_price','41000000');await w.save();
 ok('수정 저장 후 sales_plans 중복 없음',T.sales_plans.length===1,'n='+T.sales_plans.length);
 ok('수정 저장 후 sales_plan_status_rows 중복 없음',T.sales_plan_status_rows.length===1,'n='+T.sales_plan_status_rows.length+' rows='+JSON.stringify(T.sales_plan_status_rows.map(r=>[r.row_no,r.target_price])));
 /* 미등록 제번 */
 w.clearForm();setv(w,'job_no','J99999');await w.save();
 ok('미등록 제번 저장 거부',/등록된 제번이 아닙니다/.test(w.document.getElementById('message').textContent),w.document.getElementById('message').textContent);
 ok('미등록 제번으로 sales_plans 오염 없음',T.sales_plans.length===1);
 /* 2건째 계획 (row_no 충돌 검사) */
 w.clearForm();setv(w,'job_no','J26202');await w.loadJob();setv(w,'target_price','25000000');setv(w,'a5','20000000');await w.save();
 ok('2건째 계획: plans 2 / status_rows 2',T.sales_plans.length===2&&T.sales_plan_status_rows.length===2,`plans=${T.sales_plans.length} status=${T.sales_plan_status_rows.length} ids=${JSON.stringify(T.sales_plan_status_rows.map(r=>r.row_no+':'+r.job_no))}`);
 /* J26201 다시 수정 → J26202 현황행 덮어쓰기 여부 */
 w.clearForm();setv(w,'job_no','J26201');await w.loadJob();setv(w,'target_price','42000000');await w.save();
 const j2=T.sales_plan_status_rows.find(r=>r.job_no==='J26202');
 ok('J26201 재저장이 J26202 현황행을 덮어쓰지 않음',!!j2&&Number(j2.target_price)===25000000,JSON.stringify(T.sales_plan_status_rows.map(r=>r.row_no+':'+r.job_no+':'+r.target_price)));

 console.log('\n━━━ 4. 제작계획현황 (sales_plan_status) ━━━');
 w=load('sales_plan_status.html');await tick(50);
 vis=[...w.document.querySelectorAll('#body tr')].map(tr=>tr.cells[1]?.textContent);
 ok('DB 행 표시',vis.includes('J26201'),'rows='+JSON.stringify(vis));
 w.document.querySelectorAll('#body tr')[0].click();w.detail();
 ok('상세팝업이 해당 제번의 sales_plans 표시',new RegExp('제작계획등록 - '+vis[0]).test(w.document.getElementById('planTitle').textContent)&&/42,000,000|25,000,000/.test(w.document.getElementById('planBody').textContent),w.document.getElementById('planTitle').textContent);
 /* 존재하지 않는 plan 의 폴백 코드 정적 검사 */
 const spsSrc=fs.readFileSync(P+'/sales_plan_status.html','utf8');
 ok('detail(): 계획 없을 때 하드코딩 제번(G14191-S013) 폴백 없음',!/G14191-S013/.test(spsSrc),'plans.find(x=>x.job_no===\'G14191-S013\') 폴백 존재 → 다른 제번 계획이 표시될 수 있음');
 ok('editPlan(): 제작계획등록 화면의 실제 입력 id(job_no) 사용',!/getElementById\('q_job'\)/.test(spsSrc),"q_job 을 찾지만 sales_plan_input 은 id='job_no' → 제번 인계 실패(빈 화면)");
 w.document.querySelectorAll('#body tr')[0].click();await w.delPlan();
 ok('삭제 → sales_plans/status_rows 동시 제거',T.sales_plans.length===1&&T.sales_plan_status_rows.length===1,`plans=${T.sales_plans.length} status=${T.sales_plan_status_rows.length}`);

 console.log('\n━━━ 5. SET외주제작등록 (set_order_registration) ━━━');
 w=load('set_order_registration.html');await w.loadHeads();await tick();
 vis=[...w.document.querySelectorAll('#hbody tr')].map(tr=>tr.cells[0]?.textContent);
 ok('제번리스트 = 수주등록 제번(set_order_job_pool)',vis.includes('J26201')&&vis.includes('J26202'),JSON.stringify(vis));
 ok('협력업체 리스트 = set_order_partners',w.document.querySelectorAll('#vbody tr').length===2);
 await w.pick(vis.indexOf('J26201'),w.document.querySelectorAll('#hbody tr')[vis.indexOf('J26201')]);
 w.pickP('삼호텍');setv(w,'fSeq','A');setv(w,'fProc','1/1');setv(w,'fQuote','12000000');setv(w,'fNego','11000000');setv(w,'fOdate','2026-09-03');setv(w,'fRdate','2026-10-01');
 await w.save();
 ok('set_order_lines 발주 생성',T.set_order_lines.length===1&&T.set_order_lines[0].status==='발주',w.document.getElementById('message').textContent);
 ok('unit_price=nego 저장, writer=로그인자',T.set_order_lines[0].unit_price===11000000&&T.set_order_lines[0].writer==='테스터');
 await w.save();
 ok('동일 업체/조수/공정 중복발주 차단',T.set_order_lines.length===1&&/이미 발주/.test(w.document.getElementById('message').textContent),w.document.getElementById('message').textContent);
 setv(w,'fNego','13000000');setv(w,'fProc','2/2');await w.save();
 ok('네고가>견적가 차단',T.set_order_lines.length===1,w.document.getElementById('message').textContent);
 w.pickP('금도금속');setv(w,'fProc','1/1');setv(w,'fQuote','8000000');setv(w,'fNego','7500000');await w.save();
 ok('2번째 업체 발주',T.set_order_lines.length===2);

 console.log('\n━━━ 6. SET발주입고 (set_order_receipt) ━━━');
 w=load('set_order_receipt.html');await w.loadHeads();await tick();
 vis=[...w.document.querySelectorAll('#hbody tr')].map(tr=>tr.cells[0]?.textContent);
 ok('제번리스트 = 발주 존재 제번만(set_order_job_list)',vis.length===1&&vis[0]==='J26201',JSON.stringify(vis));
 await w.pick(0,w.document.querySelectorAll('#hbody tr')[0]);
 ok('미완료 탭에 발주 2건',w.document.querySelectorAll('#dbody input[type=checkbox]').length===2);
 w.document.querySelectorAll('#dbody input[type=checkbox]')[0].checked=true;await w.receive();
 const l1=T.set_order_lines.find(l=>l.partner_vendor_name==='삼호텍');
 ok('입고처리 → status=입고, receipt_date, confirmed_by',l1.status==='입고'&&!!l1.receipt_date&&l1.confirmed_by==='테스터',w.document.getElementById('message').textContent);
 ok('입고 후 미완료탭엔 1건만',w.document.querySelectorAll('#dbody input[type=checkbox]').length===1);
 w.document.querySelectorAll('#dbody input[type=checkbox]')[0].checked=true;await w.cancelOrder();
 ok('미입고 발주취소 → 라인 삭제',T.set_order_lines.length===1,w.document.getElementById('message').textContent);
 w.document.querySelector('input[name="k"][value="완료"]').checked=true;w.renderD();
 w.document.querySelectorAll('#dbody input[type=checkbox]')[0].checked=true;await w.cancelOrder();
 ok('입고건 발주취소 차단',T.set_order_lines.length===1&&/먼저 입고취소/.test(w.document.getElementById('message').textContent),w.document.getElementById('message').textContent);
 w.document.querySelectorAll('#dbody input[type=checkbox]')[0].checked=true;await w.cancelReceipt();
 ok('입고취소 → 발주 상태 복귀',T.set_order_lines[0].status==='발주'&&T.set_order_lines[0].receipt_date===null);
 w.document.querySelector('input[name="k"][value="미완료"]').checked=true;w.renderD();
 w.document.querySelectorAll('#dbody input[type=checkbox]')[0].checked=true;await w.receive();
 ok('재입고',T.set_order_lines[0].status==='입고');

 console.log('\n━━━ 7. SET발주현황 (set_order_status) ━━━');
 w=load('set_order_status.html');await w.loadRows();await tick();
 const srow=w.eval('data')[0];
 ok('발주원장×수주 조인 행 표시',w.document.querySelectorAll('#body tr').length===1&&srow.customer_name==='서성정기');
 ok('수주가=sale_orders.order_price(48M)',Number(srow.order_price)===48000000);
 ok('집행율=네고/수주가 (11M/48M=22.92%)',Number(srow.execution_rate_pct)===22.92,String(srow.execution_rate_pct));
 ok('구분 필터 "입고" 동작',(w.document.querySelector('input[name="k"][value="입고"]')||{}).value==='입고'?(()=>{w.document.querySelector('input[name="k"][value="입고"]').checked=true;w.search();return w.eval('view').length===1})():true,'(라디오 값 확인)');
 ok('합계줄 집행율 표시',/집행율 22\.9%/.test(w.document.getElementById('totline').textContent),w.document.getElementById('totline').textContent);

 console.log('\n━━━ 8. 수주취소 파급 (sale_order_input) ━━━');
 w=soWin;w.MES.clearForm();setv(w,'job_no','J26201');w.document.getElementById('job_no').dispatchEvent(new w.Event('change'));await tick(40);
 setv(w,'status','취소');r=await w.MES.save('수정');
 ok('입고된 SET발주가 있으면 수주취소 차단',r===false&&T.sale_orders[0].order_status==='진행',w.document.getElementById('message').textContent);
 setv(w,'job_no','J26202');w.document.getElementById('job_no').dispatchEvent(new w.Event('change'));await tick(40);
 setv(w,'status','취소');r=await w.MES.save('수정');
 ok('하위 발주 없는 수주는 취소 가능',r===true&&T.sale_orders.find(s=>s.job_no==='J26202').order_status==='취소');
 ok('취소 수주는 SET발주 제번풀에서 제외',!views('set_order_job_pool').some(x=>x.job_no==='J26202'));
 ok('취소가 jobs.order_status 에도 반영',T.jobs.find(j=>j.job_no==='J26202').order_status==='취소');

 console.log('\n━━━ 9. 경비등록 (expense_registration) ━━━');
 w=load('expense_registration.html');await tick();
 setv(w,'job_no','J26201');await w.loadJob();
 ok('제번 → 품명 자동채움',w.document.getElementById('item_name').value==='BRACKET,HEATER-R',w.document.getElementById('message').textContent);
 w.addRow();w.upd(0,'reason_code','E01');w.fillReason(0);w.upd(0,'amount','150,000');w.upd(0,'remark','출장');
 ok('경비사유코드 → 사유명 자동채움',w.eval('rows')[0].reason_name==='출장비');
 ok('금액 "150,000" → 숫자',w.eval('rows')[0].amount===150000);
 await w.save();
 ok('expenses 저장 (identity 채번)',T.expenses.length===1&&T.expenses[0].expense_id===1,w.document.getElementById('message').textContent);
 w.addRow();w.upd(1,'reason_name','접대비');w.upd(1,'amount','80000');await w.save();
 ok('추가 저장 시 기존행 중복 없음',T.expenses.length===2,'n='+T.expenses.length);
 ok('저장 후 customer_name 은 경비행 입력값(수주 고객사 미상속)',T.expenses[0].customer_name===null,'customer_name='+JSON.stringify(T.expenses[0].customer_name)+' (loadJob 이 customer_code/name 을 조회하지만 사용 안 함)');
 w.addRow();w.upd(2,'amount','1000');await w.save();
 ok('사유명 없는 행 저장 거부',T.expenses.length===2&&/필수/.test(w.document.getElementById('message').textContent),w.document.getElementById('message').textContent);
 w.eval('rows').pop();
 setv(w,'job_no','J99999');await w.loadJob();
 ok('미등록 제번: loadJob 경고',/수주정보 없음/.test(w.document.getElementById('message').textContent),w.document.getElementById('message').textContent);
 w.addRow();w.upd(0,'reason_name','출장비');w.upd(0,'amount','5000');
 await w.save();
 ok('미등록 제번 저장 → FK 오류 안내',/등록되지 않은 제번/.test(w.document.getElementById('message').textContent)&&T.expenses.length===2,w.document.getElementById('message').textContent);

 console.log('\n━━━ 10. 경비현황 (expense_status) ━━━');
 w=load('expense_status.html');await tick(80);
 ok('경비현황에 2건 + 합계 230,000',w.document.querySelectorAll('#ebody tr').length===2&&w.document.getElementById('gsum').textContent==='230,000',w.document.getElementById('gsum').textContent);
 ok('경비현황 품명 = 수주 품명(뷰 조인)',/BRACKET,HEATER-R/.test(w.document.getElementById('ebody').textContent));
 ok('사유 콤보 = expense_reasons',w.document.getElementById('qReason').options.length===3);
 ok('경비현황 제목 오류: "설계관리 · 외주설계발주" 표기',!/설계관리 · 외주설계발주/.test(fs.readFileSync(P+'/expense_status.html','utf8')),'title small 이 "설계관리 · 외주설계발주" 로 잘못 표기');

 console.log('\n━━━ 11. 현황판 (status_board) ━━━');
 w=load('status_board.html');await w.loadBoard();await tick();const BR=w.eval('rows');
 ok('현황판 = 취소/완료 제외 진행 수주만',BR.length===1&&BR[0].job_no==='J26201',JSON.stringify(BR.map(r=>r.job_no)));
 ok('영업담당=수주 담당자, 조립담당=제작계획 조립담당',BR[0].sales_manager==='권태윤'&&BR[0].assembly_manager==='박조립',JSON.stringify([BR[0].sales_manager,BR[0].assembly_manager]));
 ok('납기 표시 = Try-Out 예정일/납기예정일',/2026-10-05/.test(w.document.getElementById('stage').textContent)&&/2026-11-20/.test(w.document.getElementById('stage').textContent));

 console.log('\n━━━ 12. 수주 삭제 파급 (sale_order_status.delOrder) ━━━');
 w=sosWin;await tick(20);
 const idx=[...w.document.querySelectorAll('#body tr')].findIndex(tr=>tr.cells[1].textContent==='J26201');
 w.document.querySelectorAll('#body tr')[idx].click();await tick(20);
 await w.MES.delOrder();await tick(30);
 ok('수주 삭제 → sale_orders 제거, jobs 유지',!T.sale_orders.some(s=>s.job_no==='J26201')&&T.jobs.some(j=>j.job_no==='J26201'));
 ok('수주 삭제 → 수주현황행 제거(syncMaster)',!T.sale_order_status_rows.some(s=>s.job_no==='J26201'),'rows='+T.sale_order_status_rows.length);
 ok('고아 검사: 삭제된 수주의 SET발주라인/제작계획/경비가 남아 있는가',
   !(T.set_order_lines.some(l=>l.job_no==='J26201')||T.sales_plans.some(p=>p.job_no==='J26201')||T.expenses.some(e=>e.job_no==='J26201')),
   `set_order_lines=${T.set_order_lines.filter(l=>l.job_no==='J26201').length} sales_plans=${T.sales_plans.filter(p=>p.job_no==='J26201').length} expenses=${T.expenses.filter(e=>e.job_no==='J26201').length} → 삭제 전 하위건 경고 없음`);

 console.log('\n━━━ 13. 정적 검사 ━━━');
 const soi=fs.readFileSync(P+'/sale_order_input.html','utf8'),sos=fs.readFileSync(P+'/sale_order_status.html','utf8');
 const otOpts=(sos.match(/name="ot"[^>]*value="([^"]+)"/g)||[]).map(x=>x.match(/value="([^"]+)"/)[1]);
 const inOpts=(soi.match(/<select id="otype"[\s\S]*?<\/select>/)||[''])[0].match(/<option>([^<]+)/g)?.map(x=>x.slice(8))||[];
 ok('수주유형 선택지: 등록('+inOpts.join('/')+') vs 현황필터('+otOpts.join('/')+') 일치',otOpts.filter(x=>x!=='전체').every(x=>inOpts.includes(x)),'현황 필터에 있으나 등록 화면에서 선택 불가한 유형: '+otOpts.filter(x=>x!=='전체'&&!inOpts.includes(x)).join(','));
 const spi=fs.readFileSync(P+'/sales_plan_input.html','utf8');
 ok('sales_plan_input 스크립트 태그 정상 (src+inline 혼용 없음)',!/<script src="mes_ctx\.js[^>]*>\s*function/.test(spi),'<script src="mes_ctx.js?v=60">function sampleFill(){...}</script> — src 가 있으면 본문 무시 (중복 정의라 동작엔 무해)');
 const vers={};for(const f of ['sale_order_input','sale_order_status','sales_plan_input','sales_plan_status','set_order_registration','set_order_receipt','set_order_status','expense_registration','expense_status','status_board']){const m=fs.readFileSync(`${P}/${f}.html`,'utf8').match(/mes_db\.js\?v=(\d+)/);vers[f]=m?m[1]:'-'}
 ok('mes_db.js 버전 쿼리 통일',new Set(Object.values(vers)).size===1,JSON.stringify(vers));

 const bad=LOG.filter(l=>!l.c);
 console.log(`\n══ 결과: ${LOG.length}항목 중 통과 ${LOG.length-bad.length} / 실패 ${bad.length}`);
 fs.writeFileSync('/home/claude/sim_result.json',JSON.stringify({log:LOG,tables:T,sql:SQL},null,1));process.exit(0);
})().catch(e=>{console.error('SIM ERROR',e);process.exit(1)});
