-- v66 SQ DB 보정 (MCP 권한 복구 후 apply_migration 으로 적용)
-- 1) 이미 완료/검증완료된 지적사항에는 CAR 자동발행 안 함
-- 2) 화면 재저장으로 car_no 가 null 이 되면 기존 CAR 로 복원
create or replace function public.mes_car_from_finding() returns trigger
language plpgsql security definer set search_path=public as $fn$
declare v_car text;
begin
  if NEW.finding_grade not in ('Major','Minor') then return NEW; end if;
  select car_no into v_car from public.corrective_actions where finding_no = NEW.finding_no limit 1;
  if v_car is not null then
    if NEW.car_no is distinct from v_car then
      update public.quality_audit_findings set car_no = v_car where finding_no = NEW.finding_no;
    end if;
    return NEW;
  end if;
  if NEW.car_no is not null then return NEW; end if;
  if NEW.finding_status in ('완료','검증완료') then return NEW; end if;
  v_car := public.mes_next_no('CAR','corrective_actions','car_no');
  insert into public.corrective_actions(car_no, finding_no, issue_date, root_cause, action_owner, due_date, car_status, remark)
  values (v_car, NEW.finding_no, current_date, NEW.description, NEW.owner, NEW.due_date, '진행',
          '심사 지적사항 '||NEW.finding_no||' ('||NEW.finding_grade||') 자동 발행');
  update public.quality_audit_findings set car_no = v_car where finding_no = NEW.finding_no;
  return NEW;
end $fn$;
